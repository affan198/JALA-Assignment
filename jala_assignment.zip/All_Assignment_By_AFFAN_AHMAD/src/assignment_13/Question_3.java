/*
3. Write two methods with the same name and same number of parameters of same type 
and call from main method
*/
package assignment_13;

public class Question_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public boolean areEqual(int a, int b) {
		return a==b;
	}
	
	/* we cannot write same method and same parameter in same class. other wise we will get compile time error
	 * public boolean areEqual(int a, int b) { 
	 * 	return a==b;
	 *  }
	 */
}
