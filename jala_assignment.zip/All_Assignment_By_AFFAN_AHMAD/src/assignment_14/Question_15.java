/*
15. Write a program to generate NullPointerException
*/
package assignment_14;

public class Question_15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s = null;
		System.out.println(s.charAt(0));
		//or 
		System.out.println(s.length());

	}

}
