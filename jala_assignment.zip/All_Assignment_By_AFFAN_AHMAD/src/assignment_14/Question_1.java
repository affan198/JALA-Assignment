/*
1. Write a program to generate Arithmetic Exception without exception handling
*/
package assignment_14;

public class Question_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("generating arithmetic exception : "+5/0);
		//throw new ArithmeticException("this is arithmetic exception");

	}

}
