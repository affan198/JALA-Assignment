/*
3. Write a method which throws exception, Call that method in main class without try block
*/
package assignment_14;

public class Question_3 {

	static String s ;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		m1();

	}
	
	public static void m1() {
		
		System.out.println(s.charAt(0));
	}

}
