/*
16. Write a program to generate NumberFormatException
*/
package assignment_14;

public class Question_16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str = "abc";
		int num = Integer.parseInt(str);
		System.out.println(num);

	}

}
