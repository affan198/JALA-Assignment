/*
17. Write a program to generate StringIndexOutOfBoundsException
*/
package assignment_14;

public class Question_17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str = "abc";
		System.out.println(str.charAt(4));

	}

}
