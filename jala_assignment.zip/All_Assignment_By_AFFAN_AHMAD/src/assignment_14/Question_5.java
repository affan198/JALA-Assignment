/*
5. Write a program to throw exception with your own message
*/
package assignment_14;

public class Question_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		throw new ArithmeticException("this is /0 exception");

	}

}
