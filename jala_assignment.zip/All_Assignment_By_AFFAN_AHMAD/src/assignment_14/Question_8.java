/*
8. Write a program to generate Arithmetic Exception
*/
package assignment_14;

public class Question_8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a = 5/0; // Arithmetic exception occur here
		System.out.println(a);

	}

}
