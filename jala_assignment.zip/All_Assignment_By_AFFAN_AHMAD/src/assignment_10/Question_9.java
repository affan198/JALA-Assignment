/*
9. Create a PRIVATE or PROTECTED interface and print the values as above scenario
*/
package assignment_10;

public class Question_9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

//private and protected access modifier is not allowed for interface 

/*
 * protected interface XYZ{ int a = 45; String name = "AFFAN";
 * 
 * void method() ; }
 * 
 * class ChildOfXYZ implements XYZ{
 * 
 * @Override public void method() { System.out.println("ChildOfXYZ.method()"); }
 * 
 * }
 */
