/*
3. Program to equal operator and not equal operators
*/
package assignment_3;

public class Question_3 {

	public static void main(String[] args) {

		int a = 2;
		int b = 3;
		int c = 3;

		if (c == b) {
			System.out.println("if c and b are equal this block will execute");
		}
		if (a != b) {
			System.out.println("if a is not equal to b this block will be eecuted");
		}

	}

}
