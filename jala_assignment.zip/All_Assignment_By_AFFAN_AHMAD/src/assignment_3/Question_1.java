/*
1. Write a program to print “Bright IT Career” ten times using for loop
*/
package assignment_3;

public class Question_1 {

	public static void main(String[] args) {


		for(int i=1 ; i<=10 ; i++) {
			System.out.println("Bright IT Career");
		}
		
	}

}
