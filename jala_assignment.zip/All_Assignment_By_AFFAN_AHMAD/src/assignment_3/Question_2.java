/*
2. Write a java program to print 1 to 20 numbers using the while loop.
*/

package assignment_3;

public class Question_2 {

	public static void main(String[] args) {

		int i = 1;
		while (i <= 20) {
			System.out.println(i);
			i++;

		}

	}

}
