/*
9. Trimming strings with trim()
*/
package assignment_6;

public class Question_9 {

	public static void main(String[] args) {

		String name = "    AFFAN   AHMAD   ";
		String trim = name.trim(); // remove spaces from front an end but not in middle.
		System.out.println(trim);
	}

}
