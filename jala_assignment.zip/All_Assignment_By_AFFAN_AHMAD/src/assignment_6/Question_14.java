/*
14. Converting to upper case and lower case
*/
package assignment_6;

public class Question_14 {

	public static void main(String[] args) {

		String name = "AFFAN AHAMD";
		String lowerCase = name.toLowerCase();
		System.out.println(lowerCase);
		
		String upperCase = lowerCase.toUpperCase();
		System.out.println(upperCase);
	}

}
