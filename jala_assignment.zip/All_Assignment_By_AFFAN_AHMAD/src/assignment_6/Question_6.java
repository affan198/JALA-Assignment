/*
6. Matching a String Against a Regular Expression With matches()
*/
package assignment_6;

public class Question_6 {

	public static void main(String[] args) {

		String name = "AFFAN AHMAD";
		boolean matches = name.matches("AFFAN");
		System.out.println(matches);
	}

}
