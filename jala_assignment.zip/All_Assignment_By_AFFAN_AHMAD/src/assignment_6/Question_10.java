/*
10. Replacing characters in strings with replace()
*/
package assignment_6;

public class Question_10 {

	public static void main(String[] args) {

		String name = "AFFAN";
		String replace = name.replace('F', 'f');
		System.out.println(replace);
	}

}
