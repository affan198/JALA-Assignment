/*
13. Converting integer objects to Strings
*/
package assignment_6;

public class Question_13 {

	public static void main(String[] args) {

		Integer a = 45;
		String valueOf = String.valueOf(a);
		System.out.println(valueOf);
	}

}
