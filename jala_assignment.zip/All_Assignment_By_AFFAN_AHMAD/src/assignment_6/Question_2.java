/*
2. Concatenating two strings using + operator
*/
package assignment_6;

public class Question_2 {

	public static void main(String[] args) {

		String s1 = "AFFAN ";
		String s2 = "AHMAD";
		
		String concat = s1+s2;
		System.out.println("contactenation : "+concat);
	}

}
