/*
3. Finding the length of the string
*/
package assignment_6;

public class Question_3 {

	public static void main(String[] args) {

		String str = "AFFAN";
		int length = str.length();
		System.out.println("length of the string is : "+length);
	}

}
