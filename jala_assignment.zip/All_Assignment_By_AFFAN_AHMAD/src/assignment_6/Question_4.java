/*
4. Extract a string using Substring
*/
package assignment_6;

public class Question_4 {

	public static void main(String[] args) {

		String name = "AFFAN AHMAD";
		String lName = name.substring(6);
		String fName = name.substring(0, 5);
		System.out.println("first name : "+fName+"  last name : "+lName);
		
	}

}
