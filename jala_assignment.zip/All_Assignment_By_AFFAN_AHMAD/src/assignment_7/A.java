package assignment_7;

public class A {
	
	protected int vr =55;
	
	public int firstMethodOfA() {
		System.out.println("A.firstMethodOfA()");
		return 1;
	}
	
	public int secondMethodOfA() {
		System.out.println("A.secondMethodOfA()");
		return 1;
	}
	
	public String generalmethod() {
		System.out.println("A.generalmethod()");
		return "general method of A class";
	}

}
