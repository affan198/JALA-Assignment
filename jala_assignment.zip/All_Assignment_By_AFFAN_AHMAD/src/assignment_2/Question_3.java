/*
3. Program to equal operator and not equal operators
*/
package assignment_2;

public class Question_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a = 4;
		int b = 6;
		int c = 4;

		boolean ab = a == b;
		System.out.println("does 'a' and 'b' equal : " + ab);

		boolean ac = a == c;
		System.out.println("does 'a' and 'c' equal : " + ac);

	}

}
