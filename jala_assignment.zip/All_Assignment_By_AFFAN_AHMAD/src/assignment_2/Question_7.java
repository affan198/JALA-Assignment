/*
7. Print the smaller and larger number
*/
package assignment_2;

public class Question_7 {

	public static void main(String[] args) {

		int a = 3;
		int b = 7;

		if (a > b) {
			System.out.println("a is greater than b");
		} else if (b > a) {
			System.out.println("b is greater than a");
		} else {
			System.out.println("both are eaual");
		}

	}

}
