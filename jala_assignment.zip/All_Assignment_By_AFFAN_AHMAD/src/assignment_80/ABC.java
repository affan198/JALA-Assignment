package assignment_80;

import assignment_8.Question_4;

public class ABC {

	public static void main(String[] args) {

		Question_4 obj = new Question_4();
		System.out.println(obj.addr);
		System.out.println(obj.accessAddr());
	}

}
