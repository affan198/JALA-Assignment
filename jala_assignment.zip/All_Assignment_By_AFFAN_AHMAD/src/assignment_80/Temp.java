package assignment_80;

import assignment_8.Question_3;

public class Temp {

	public static void main(String[] args) {

		Question_3 obj = new Question_3();
		//obj.name; // we cannot access protected field from any class of different package
		//obj.accessName(); we cannot access protected method from any class of different package
	}

}
