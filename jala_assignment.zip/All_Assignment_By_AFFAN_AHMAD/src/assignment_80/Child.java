package assignment_80;

import assignment_8.Question_3;

public class Child extends Question_3 {

	public static void main(String[] args) {
		Child child = new Child();
		System.out.println(child.name);
		System.out.println(child.accessName());
	}

}
