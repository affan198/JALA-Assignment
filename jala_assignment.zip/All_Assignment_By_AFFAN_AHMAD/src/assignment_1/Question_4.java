/*
4. Define variables for different Data Types int, Boolean, char, float, double and print on the 
 Console
*/
package assignment_1;

public class Question_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i = 35;
		boolean b = false;
		char ch = 'a';
		float f = 45.7f;
		double d = 87.12;
		System.out.println("this is int ariable : "+i);
		System.out.println("this is boolean ariable : "+b);
		System.out.println("this is char ariable : "+ch);
		System.out.println("this is float ariable : "+f);
		System.out.println("this is double ariable : "+d);

	}

}
