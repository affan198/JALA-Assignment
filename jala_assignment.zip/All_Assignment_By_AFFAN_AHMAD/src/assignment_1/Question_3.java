/*
3. Write a program for a Single line comment, multi-line and documentation comments
*/

package assignment_1;

public class Question_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		//this is single line comment//
		
		
		/* 
		 this 
		 is 
		 multi-line 
		 comment 
		*/
		/* 
		 *this 
		 *is 
		 *multi-line 
		 *comment 
		*/

		
		
		//this is single line format
		System.out.println("//this is single line comment//");
		
		/*
		 this 
		 is 
		 multiline 
		 comment.
		 */
		
		System.out.println("/* \n this \n is \n multi-line \n comment \n*/");
		
		/*
		 * this 
		 * is 
		 * documentation 
		 * comment.
		 */
		
		System.out.println("/* \n *this \n *is \n *documentaion \n *comment \n*/");
	}

}
